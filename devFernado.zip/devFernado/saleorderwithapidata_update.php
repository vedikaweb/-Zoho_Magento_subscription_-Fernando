<?php

$today = date("Y-m-d");
    //echo $today = "2021-02-01";

file_put_contents("Fernando Cron Trigger.txt","\n".print_r(date("Y-m-d H:i:s"),true),FILE_APPEND);
//files included for connection to the database and oauthentication for zoho 
require("dbConnect.php");
require('oauth_token_zoho.php');

//Get zoho token from db.
$tokenQuery="SELECT * FROM `fr_oauth_token` where token_type='CRM'";
$tokenQueryRes =$conn->query($tokenQuery);
	if ($tokenQueryRes->num_rows>0) {
		$tokenRow = mysqli_fetch_assoc($tokenQueryRes);
		$tokenzoho="Zoho-oauthtoken ".$tokenRow['access_token'];
	}

//Code is for fetching data from Mangento via rest api using token.
//$requestUrl='http://52.25.19.29/ca/rest/all/V1/orders?searchCriteria%5BcurrentPage%5D=0';


//$requestUrl='http://52.25.19.29/ca/rest/all/V1/orders/169';
echo $requestUrl='http://52.25.19.29/ca/rest/all/V1/orders?searchCriteria[filter_groups][0][filters][0][field]=updated_at&searchCriteria[filter_groups][0][filters][0][value]='.$today.'&searchCriteria[filter_groups][0][filters][0][condition_type]=from';

//$requestUrl='http://52.25.19.29/ca/rest/all/V1/orders/174';

$magentotoken='Bearer tjfij5xewlkj2qk03ujbio8k9b0mf2bb';
$api_result= curl_call($magentotoken,$requestUrl);

//function to call get api call from Mangento
function curl_call($magentotoken,$requestUrl){
       
	$curl = curl_init();

  curl_setopt_array($curl, array(
  CURLOPT_URL => $requestUrl,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_SSL_VERIFYPEER => FALSE,
  CURLOPT_SSL_VERIFYHOST => FALSE,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_HTTPHEADER => array(
    "Content-Type: application/json",
    "Authorization: Bearer tjfij5xewlkj2qk03ujbio8k9b0mf2bb",
    "Cookie: PHPSESSID=rs86nf23vp7v0g5ufa5khljsh6"
  ),
));
	$response = curl_exec($curl);
	curl_close($curl);
    $responsedata = json_decode($response,true);
    
    return $responsedata; 
		          
} //function curl_call end

echo"<pre>";

//$orders=$api_result['items'];

// create data for api requeset
$resultData=$api_result['items'];

if(!empty($resultData)){
    
  //  print_r($api_result);
//die;
    
foreach($resultData as $result){
			$customer_email= $result['customer_email'];
            $customer_firstname= $result['customer_firstname'];
			$customer_lastname= $result['customer_lastname'];
			$status = $result['status'];
		//	$shipping_amount= $result['shipping_invoiced'];
			$shipping_amount= $result['shipping_amount'];
			$Mag_order_id= $result['increment_id'];
			$base_tax_invoiced= $result['base_tax_invoiced'];
			
			$subject=$customer_firstname." ".$customer_lastname;
		
		
		    $payment = $result['payment'];
		    $cc_exp_month = $payment['cc_exp_month'];
		    $cc_exp_year = $payment['cc_exp_year'];
		    $cc_type = $payment['cc_type'];
		    $method = $payment['method'];
		    $cc_last4 = $payment['cc_last4'];
			if($cc_last4 ==''){
			    $cc_last4 = 0;
			}
			$Billing_City= $result['billing_address']['city'];
			$Billing_Country= $result['billing_address']['country_id'];
			$Billing_Code= $result['billing_address']['postcode'];
			$Billing_State= $result['billing_address']['region'];
			$billing_address_arr= $result['billing_address']['street'];
			$Home_Telephone= $result['billing_address']['telephone'];
			
			$Billing_Street='';
			foreach($billing_address_arr as $street1)
			{
				 $Billing_Street=$Billing_Street.' '.$street1;
			}
			
			$shipping_address= $result['extension_attributes']['shipping_assignments'][0]['shipping']['address'];

			
			//echo $streetadd;
			
		
			$Shipping_City= $shipping_address['city'];
			$Shipping_Country = $shipping_address['country_id'];
			$Shipping_Code= $shipping_address['postcode'];
			$Shipping_State= $shipping_address['region'];
			
			//get tax detials from the states names from zoho 
			$taxdetails=search_zoho_tax($Shipping_State);
			
			
			$shipping_address_arr= $result['billing_address']['street'];
			$Shipping_Street='';
			foreach($shipping_address_arr as $shi_street1)
			{
				 $Shipping_Street=$Shipping_Street.' '.$shi_street1;
			}
			
			$Work_Mobile= $shipping_address['telephone'];
		
			$items_arr=$result['items'];
		//print_r($items_arr);
		
		
		//CHECK IN DATABASE
		$sql = "SELECT * FROM fr_magento_order where magentoID='".$Mag_order_id."' and status=1";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
  // output data of each row
  
  while($rowOrder = mysqli_fetch_assoc($result)) {
    $orderZcrmID = $rowOrder["ZcrmID"];
  }
  
  
  
  $sqlUpdate = "Update fr_magento_order Set magentoID='".$Mag_order_id."', status='2', sync_date='".$today."',card_number='".$cc_last4."',card_type='".$cc_type."',card_exp_month='".$cc_exp_month."',card_exp_year='".$cc_exp_year."',payment_method='".$method."',customer_first_name='".$customer_firstname."',customer_last_name='".$customer_lastname."',customer_email='".$customer_email."',Billing_Street='".$Billing_Street."',Billing_City='".$Billing_City."',Billing_State='".$Billing_State."',Billing_Code='".$Billing_Code."',Billing_Country='".$Billing_Country."',Shipping_Street='".$Shipping_Street."',Shipping_City='".$Shipping_City."',Shipping_State='".$Shipping_State."',Shipping_Code='".$Shipping_Code."',Shipping_Country='".$Shipping_Country."' where magentoID='".$Mag_order_id."'";
                    
                    if (mysqli_query($conn, $sqlUpdate)) {
                      echo "Order record updated successfully";
                    } else {
                      echo "Error: " . $sqlUpdate . "<br>" . mysqli_error($conn);
                    }
					

  

		
		
		//GET CONTACT DETAILS CRM
			echo "requestCustomerUrl==>>".$requestCustomerUrl="https://www.zohoapis.com/crm/v2/Contacts/search?criteria=((Email:equals:{$customer_email}))";
				
				$curl = curl_init();

				  curl_setopt_array($curl, array(
				  CURLOPT_URL => $requestCustomerUrl,
				  CURLOPT_RETURNTRANSFER => true,
				  CURLOPT_ENCODING => "",
				  CURLOPT_MAXREDIRS => 10,
				  CURLOPT_TIMEOUT => 0,
				  CURLOPT_SSL_VERIFYPEER => FALSE,
				  CURLOPT_SSL_VERIFYHOST => FALSE,
				  CURLOPT_FOLLOWLOCATION => true,
				  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				  CURLOPT_CUSTOMREQUEST => "GET",
				  CURLOPT_HTTPHEADER => array(
                    "Authorization: ".$tokenzoho,
                    'Content-Type: application/x-www-form-urlencoded',
                ),
				));
				$response_customer = curl_exec($curl);
                curl_close($curl);
                $responsecustomerdata = json_decode($response_customer,true);
		echo "<pre>";
		echo "CUSTOMER==>>>"; echo "</br>";
		print_r($responsecustomerdata);
		//die; 
		 if(isset($responsecustomerdata['data'][0])){
		    echo "CUSTOMER FOUND IF";
		    $contactID = $responsecustomerdata['data'][0]['id'];
		}else{
		    $requestUrl='https://enviro.developmentpreviews.com/rest/V1/customers/search?searchCriteria[filterGroups][0][filters][0][field]=email&searchCriteria[filterGroups][0][filters][0][value]='.$customer_email.'&searchCriteria[filterGroups][0][filters][0][condition_type]=like';
                $token='Bearer tjfij5xewlkj2qk03ujbio8k9b0mf2bb';
                
                
                $api_result= curl_call($token,$requestUrl);
                echo "CUSTOMER NOT FOUND IF";
                echo"<pre>";
                
                //print_r($api_result);
                $CustData = $api_result['items'][0];
                $firstname = $CustData['firstname'];
                $lastname = $CustData['lastname'];
                $email = $CustData['email'];
                $addresses = $CustData['addresses'];
                $BillStreet = '';
                $ShipStreet='';
                $cust_body2='';
			     $cust_body='';
			     
                foreach($addresses as $eachaddress){
                    //print_r($eachaddress);
                    if($eachaddress['default_billing'] == 1){
                        print_r($eachaddress['street']);
                        $BillstreetData = $eachaddress['street'];
                        foreach($BillstreetData as $BillRowStreet){
                            $BillStreet .=$BillRowStreet.' ';
                        }
                    
                    
                        $Billregion = $eachaddress['region']['region_code'];
                        $Billcountry_id = $eachaddress['country_id'];
                        $Homephone = $eachaddress['telephone'];
                        $Billpostcodee = $eachaddress['postcode'];
                        $Billcity = $eachaddress['city'];
                    }
                    
                    if($eachaddress['default_shipping'] == 1){
                        //print_r($eachaddress['street']);
                        $ShipstreetData = $eachaddress['street'];
                        foreach($ShipstreetData as $ShipRowStreet){
                            $ShipStreet .=$ShipRowStreet.' ';
                        }
                    
                    
                        $Shipregion = $eachaddress['region']['region_code'];
                        $Shipcountry_id = $eachaddress['country_id'];
                        $Mobile = $eachaddress['telephone'];
                        $Shippostcodee = $eachaddress['postcode'];
                        $Shipcity = $eachaddress['city'];
                    }
                    
                    
                }
                $cust_body.='{
                          "data": [
                            {
								"Account_Name":"'.$firstname.' '. $lastname.'",
								"First_Name":"'.$firstname.'",
								"Last_Name":"'.$lastname.'",
								"Email":"'.$email.'",
                                "Mobile":"'.$Mobile.'",
								"Home_Phone":"'.$Homephone.'",
									"Other_City":"'.$Shipcity.'",
								"Other_Country	":"'.$Shipcountry_id.'",
								"Other_Street":"'.$ShipStreet.'",
								"Other_Zip":"'.$Shippostcodee.'",
								"Other_State":"'.$Shipregion.'",
								"Mailing_City":"'.$Billcity.'",
								"Mailing_Country":"'.$Billcountry_id.'",
								"Mailing_State":"'.$Billregion.'",
								"Mailing_Street":"'.$BillStreet.'",
								"Mailing_Zip":"'.$Billpostcodee.'",
								},';
                $cust_body2.=rtrim($cust_body, ',');
				$cust_body2.=']
					}';
					echo "CUSTOMER DATA";
		print_r($cust_body2);
					
					$CustUrl="https://www.zohoapis.com/crm/v2/Contacts";
        		$ch = curl_init();
                curl_setopt($ch, CURLOPT_URL,$CustUrl);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
                curl_setopt($ch, CURLOPT_TIMEOUT,30);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);    
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS,$cust_body2);
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST,"POST");
                curl_setopt($ch,CURLOPT_HTTPHEADER, array(
                "Authorization: ".$tokenzoho));
                $result = curl_exec($ch);
        		  echo "<pre>";
        		$CreateResponse=(json_decode($result,true));
        		print_r($CreateResponse);
        	if(isset($CreateResponse['data'][0]['code']) && $CreateResponse['data'][0]['code'] == 'SUCCESS'){
        		$contactID = $CreateResponse['data'][0]['details']['id'];
        	}
					
		}
		
		/////////////////////
		
		
		
		
		//Sales_Orders body for zoho request
			    $so_body2='';
			     $so_body='';
			     if($cc_exp_month == ''){
			         $cc_exp_month=0;
			     }
			     $so_body.='{
					"data": [{
						"Contact_Name":"'.$contactID.'",
						"Subject": "'.$subject.'",
						"Home_Telephone": "'.$Home_Telephone.'",
						"Billing_Street": "'.ltrim($Billing_Street).'",
						"Billing_City": "'.$Billing_City.'",
						"Billing_Country": "'.$Billing_Country.'",
						"Billing_Code": "'.$Billing_Code.'",
						"Billing_State": "'.$Billing_State.'",
						"Work_Mobile": "'.$Work_Mobile.'",
						"Shipping_Street": "'.ltrim($Shipping_Street).'",
						"Shipping_City": "'.$Shipping_City.'",
						"Shipping_Country": "'.$Shipping_Country.'",
						"Shipping_Code": "'.$Shipping_Code.'",
						"Shipping_State": "'.$Shipping_State.'",
						"Magento_Order_No": "'.$Mag_order_id.'",
						"Card_Number": '.$cc_last4.',
						"Card_Type": "'.$cc_type.'",
						"Payment_Method": "'.$method.'",
						"Card_Expiry_Month":'.$cc_exp_month.',
						"Card_Expiry_Year":'.$cc_exp_year.',
						"$line_tax": '.$taxdetails.',
						"Status": '.$status.',
						"Product_Details": [';
						
						
					      	foreach($items_arr as $item) {
								
								$SKU=$item['sku'];
								
								//get product internal id by item code in mangento
								$product_id=search_zoho_product_id($tokenzoho,$SKU);
								
								
								
								
								
								
								
								
															
								
								$so_body.='{
									"quantity": '.$item['qty_ordered'].',
									"Discount": '.$item['discount_amount'].',
									"list_price": '.$item['base_price'].',
									"unit_price": '.$item['base_price'].',
									"product":{
									  "id": '.$product_id.'
									},
									"line_tax": []
								},';
								
								$sqlLinesDelete = "DELETE FROM fr_magento_order_items where magentoID='".$Mag_order_id."' and product_id='".$product_id."'";

								if ($conn->query($sqlLinesDelete) === TRUE) {
								  echo "Record deleted successfully";
								} else {
								  echo "Error deleting record: " . $conn->error;
								}

								$sqlLines = "SELECT * FROM fr_magento_order_items where magentoID='".$Mag_order_id."' and product_id='".$product_id."'";
$sqlLinesresult = mysqli_query($conn, $sqlLines);

if (mysqli_num_rows($sqlLinesresult) > 0) {
  // output data of each row
 
} else {
								
								$sqlItems = "INSERT INTO fr_magento_order_items (magentoID,product_id, sku, qty_ordered,discount_amount,base_price,base_tax_invoiced,row_total_incl_tax)
                                VALUES ('".$Mag_order_id."', '".$product_id."', '".$SKU."', '".$item['qty_ordered']."', '".$item['discount_amount']."','".$item['base_price']."','".$item['base_tax_invoiced']."', '".$item['row_total_incl_tax']."')";
                                
                                if (mysqli_query($conn, $sqlItems)) {
                                  echo "New Order Item record created successfully";
                                } else {
                                  echo "Error: " . $sqlItems . "<br>" . mysqli_error($conn);
                                }
}
								
							}
						$so_body .='{

									"product": { 

										"name": "Shipping",
										"id": "4608276000000415179",

									},
	
									"quantity": 1.00,
									"list_price": '.$shipping_amount.',

                    
								}';
				$so_body2.=rtrim($so_body, ',');
				$so_body2.=']
						}]
					}';
print_r($so_body2);

			//call to salesorderUrl api.
				$salesorderUrl = "https://www.zohoapis.com/crm/v2/Sales_Orders/".$orderZcrmID;
				$createOrderRes=postRequest($tokenzoho,$salesorderUrl,$so_body2);
				echo "<pre>";
				
				$createOrderResData = json_decode($createOrderRes,true);
				print_r($createOrderResData);
				if($createOrderResData['data'][0]['code'] == 'SUCCESS'){
				    $ZcrmID = $createOrderResData['data'][0]['details']['id'];
				    
				    
				    
				    $sql = "UPDATE fr_magento_order SET ZcrmID='".$ZcrmID."', status=1 WHERE magentoID='".$Mag_order_id."'";

                    if (mysqli_query($conn, $sql)) {
                      echo "Record updated successfully";
                    } else {
                      echo "Error updating record: " . mysqli_error($conn);
                    }
				    
				    
				}else{
				    
				}					
					
					
					
} else {
  
  

}

//GET SUBSCRIPTION DATA
echo $requestUrl='http://52.25.19.29/ca/rest/all/V1/subscriptions?searchCriteria[filterGroups][0][filters][0][field]=initial_order_id&searchCriteria[filterGroups][0][filters][0][value]='.$Mag_order_id.'&searchCriteria[filterGroups][0][filters][0][condition_type]=like';

//$requestUrl='http://52.25.19.29/ca/rest/all/V1/orders/174';

$magentotoken='Bearer tjfij5xewlkj2qk03ujbio8k9b0mf2bb';
$api_result= curl_call($magentotoken,$requestUrl);



echo"<pre>";

//$orders=$api_result['items'];

// create data for api requeset
$resultDataSub=$api_result['items'];

if(!empty($resultDataSub)){
    
    //print_r($resultDataSub);
   // die;
    
foreach($resultDataSub as $resultEachDataSub){
			$subscription_id= $resultEachDataSub['subscription_id'];
            $customer_id= $resultEachDataSub['customer_id'];
			$magento_product_id= $resultEachDataSub['product_id'];
			
			$subscriber_name= $resultEachDataSub['subscriber_name'];
			$subscriber_email= $resultEachDataSub['subscriber_email'];
			$subscription_start_date= $resultEachDataSub['subscription_start_date'];
			$next_occurrence_date= $resultEachDataSub['next_occurrence_date'];
			$payment_method_code=$resultEachDataSub['payment_method_code'];
		
		
		    $billing_period_label = $resultEachDataSub['billing_period_label'];
		    $billing_period = $resultEachDataSub['billing_period'];
		    $billing_frequency = $resultEachDataSub['billing_frequency'];
		    $period_max_cycles = $resultEachDataSub['period_max_cycles'];
		    $billing_amount = $resultEachDataSub['billing_amount'];
		    $payment_title = $resultEachDataSub['payment_title'];
			
			$product_name= $resultEachDataSub['product_name'];
			$initial_order_id= $resultEachDataSub['initial_order_id'];
			$additional_info = $resultEachDataSub['additional_info'];
			$additional_infoData = json_decode($additional_info,true);
			//print_r(json_decode($additional_info,true));
			echo $product_sku = $additional_infoData['product_sku'];
			
			$subscription_start_date = date("Y-m-d", strtotime($subscription_start_date));
			$next_occurrence_date = date("Y-m-d", strtotime($next_occurrence_date));
		
		
		//GET ITEMS CUSTOM OPTIONS
		$requestUrlCST='https://enviro.developmentpreviews.com/rest/V1/products/'.$product_sku;
        // $requestUrl='https://enviro.developmentpreviews.com/rest/V1/carts/search?searchCriteria[pageSize]=0';
        $token='Bearer tjfij5xewlkj2qk03ujbio8k9b0mf2bb';


        $api_resultCST= curl_call($token,$requestUrlCST);
        //print_r($api_resultCST);
        $ReminderAfter='';
        $ReminderTypeAfter='';
        $options = $api_resultCST['options'];
        foreach($options as $eachoptions){
           if($eachoptions['title'] == 'Let us remind you to replace every'){
                $ReminderValues = $eachoptions['values'];
                //print_r($ReminderValues);
                foreach($ReminderValues as $eachReminderValues){
                    $ReminderActualValue = $eachReminderValues['title'];
                    if (strpos($ReminderActualValue, 'Recommended') !== false) {
                       // echo 'true';
                       // print_r(explode('months',$ReminderActualValue));
                        $ReminderArray = explode('months',$ReminderActualValue);
                        $ReminderAfter = $ReminderArray[0];
                        $ChangeFilterReminderDate = date('Y-m-d', strtotime("+".$ReminderAfter. "months", strtotime($subscription_start_date)));
                    }
                }
            } 
            if($eachoptions['title'] == 'Reminder type'){
                $ReminderTypeValues = $eachoptions['values'];
                foreach($ReminderTypeValues as $eachTypeReminderValues){
                $ReminderTypeActualValue = $eachTypeReminderValues['title'];
                if (strpos($ReminderTypeActualValue, 'Recommended') !== false) {
                        echo 'true';
                        print_r(explode('(Recommended)',$ReminderTypeActualValue));
                        $ReminderTypeArray = explode('(Recommended)',$ReminderTypeActualValue);
                        $ReminderTypeAfter = $ReminderTypeArray[0];
                    }
                }
            } 
        }
        
        
        
        //die;
//END GET ITEMS CUSTOM OPTIONS
		
		
		//CHECK IN DATABASE
		$sql = "SELECT * FROM fr_magento_subscriptions where subscription_id='".$subscription_id."' and status=1";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
  // output data of each row
  while($rowOrderSub = mysqli_fetch_assoc($result)) {
    $subscription_ZcrmID = $rowOrderSub["subscription_id"];
  }
  
    //CHECK FOR IF ORDER IN STATUS 0
  $sqlCheck = "SELECT * FROM fr_magento_subscriptions where subscription_id='".$subscription_id."' and status=0";
$resultsqlCheck = mysqli_query($conn, $sqlCheck);
//echo "ROWS NUMBER==>>". mysqli_num_rows($resultsqlCheck); echo "</br>";
if (mysqli_num_rows($resultsqlCheck) > 0) {
   $sqlUpdate = "Update fr_magento_subscriptions Set subscription_id='".$subscription_id."', status='0', customer_id='".$customer_id."',magento_product_id='".$magento_product_id."',subscriber_name='".$subscriber_name."',subscriber_email='".$subscriber_email."',subscription_start_date='".$subscription_start_date."',next_occurrence_date='".$next_occurrence_date."',payment_method_code='".$payment_method_code."',billing_period_label='".$billing_period_label."',billing_period='".$billing_period."',billing_frequency='".$billing_frequency."',period_max_cycles='".$period_max_cycles."',billing_amount='".$billing_amount."',payment_title='".$payment_title."',product_name='".$product_name."',initial_order_id='".$initial_order_id."',reminder_fre= '".$ReminderAfter."',reminder_type = '".$ReminderTypeAfter."'  where subscription_id='".$subscription_id."'";
                    
                    if (mysqli_query($conn, $sqlUpdate)) {
                      echo "Order record updated successfully";
                    } else {
                      echo "Error: " . $sqlUpdate . "<br>" . mysqli_error($conn);
                    }
} else {
    
    $sql = "INSERT INTO fr_magento_subscriptions (subscription_id,status, customer_id,magento_product_id,subscriber_name,subscriber_email,subscription_start_date,next_occurrence_date,payment_method_code,billing_period_label,billing_period,billing_frequency,period_max_cycles,billing_amount,payment_title,product_name,initial_order_id,reminder_fre,reminder_type)
                    VALUES ('".$subscription_id."', '0', '".$customer_id."', '".$magento_product_id."', '".$subscriber_name."','".$subscriber_email."','".$subscription_start_date."', '".$next_occurrence_date."', '".$payment_method_code."', '".$billing_period_label."','".$billing_period."', '".$billing_frequency."', '".$period_max_cycles."','".$billing_amount."','".$payment_title."','".$product_name."','".$initial_order_id."','".$ReminderAfter."','".$ReminderTypeAfter."')";
                    
                    if (mysqli_query($conn, $sql)) {
                      echo "New Order record created successfully";
                    } else {
                      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
                    }
    
}
  

		$contactID = '';
		    $Full_Name = '';
		    $SOID = '';
		
		//GET CONTACT DETAILS CRM
			echo "requestCustomerUrl==>>".$requestCustomerUrl="https://www.zohoapis.com/crm/v2/Contacts/search?criteria=((Email:equals:{$subscriber_email}))";
				
				$curl = curl_init();

				  curl_setopt_array($curl, array(
				  CURLOPT_URL => $requestCustomerUrl,
				  CURLOPT_RETURNTRANSFER => true,
				  CURLOPT_ENCODING => "",
				  CURLOPT_MAXREDIRS => 10,
				  CURLOPT_TIMEOUT => 0,
				  CURLOPT_SSL_VERIFYPEER => FALSE,
				  CURLOPT_SSL_VERIFYHOST => FALSE,
				  CURLOPT_FOLLOWLOCATION => true,
				  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				  CURLOPT_CUSTOMREQUEST => "GET",
				  CURLOPT_HTTPHEADER => array(
                    "Authorization: ".$tokenzoho,
                    'Content-Type: application/x-www-form-urlencoded',
                ),
				));
				$response_customer = curl_exec($curl);
                curl_close($curl);
                $responsecustomerdata = json_decode($response_customer,true);
		//echo "<pre>";
		echo "CUSTOMER==>>>"; echo "</br>";
		print_r($responsecustomerdata);
		//die;
		
		if(isset($responsecustomerdata['data'][0])){
		    $contactID = $responsecustomerdata['data'][0]['id'];
		    $Full_Name = $responsecustomerdata['data'][0]['Full_Name'];
		    
		}else{
		    $requestUrl='https://enviro.developmentpreviews.com/rest/V1/customers/search?searchCriteria[filterGroups][0][filters][0][field]=email&searchCriteria[filterGroups][0][filters][0][value]='.$customer_email.'&searchCriteria[filterGroups][0][filters][0][condition_type]=like';
                $token='Bearer tjfij5xewlkj2qk03ujbio8k9b0mf2bb';
                
                
                $api_result= curl_call($token,$requestUrl);
                echo "CUSTOMER NOT FOUND IF";
                echo"<pre>";
                
                //print_r($api_result);
                $CustData = $api_result['items'][0];
                $firstname = $CustData['firstname'];
                $lastname = $CustData['lastname'];
                $email = $CustData['email'];
                $addresses = $CustData['addresses'];
                $BillStreet = '';
                $ShipStreet='';
                $cust_body2='';
			     $cust_body='';
			     
                foreach($addresses as $eachaddress){
                    //print_r($eachaddress);
                    if($eachaddress['default_billing'] == 1){
                        print_r($eachaddress['street']);
                        $BillstreetData = $eachaddress['street'];
                        foreach($BillstreetData as $BillRowStreet){
                            $BillStreet .=$BillRowStreet.' ';
                        }
                    
                    
                        $Billregion = $eachaddress['region']['region_code'];
                        $Billcountry_id = $eachaddress['country_id'];
                        $Homephone = $eachaddress['telephone'];
                        $Billpostcodee = $eachaddress['postcode'];
                        $Billcity = $eachaddress['city'];
                    }
                    
                    if($eachaddress['default_shipping'] == 1){
                        //print_r($eachaddress['street']);
                        $ShipstreetData = $eachaddress['street'];
                        foreach($ShipstreetData as $ShipRowStreet){
                            $ShipStreet .=$ShipRowStreet.' ';
                        }
                    
                    
                        $Shipregion = $eachaddress['region']['region_code'];
                        $Shipcountry_id = $eachaddress['country_id'];
                        $Mobile = $eachaddress['telephone'];
                        $Shippostcodee = $eachaddress['postcode'];
                        $Shipcity = $eachaddress['city'];
                    }
                    
                    
                }
                $cust_body.='{
                          "data": [
                            {
								"Account_Name":"'.$firstname.' '. $lastname.'",
								"First_Name":"'.$firstname.'",
								"Last_Name":"'.$lastname.'",
								"Email":"'.$email.'",
                                "Mobile":"'.$Mobile.'",
								"Home_Phone":"'.$Homephone.'",
									"Other_City":"'.$Shipcity.'",
								"Other_Country	":"'.$Shipcountry_id.'",
								"Other_Street":"'.$ShipStreet.'",
								"Other_Zip":"'.$Shippostcodee.'",
								"Other_State":"'.$Shipregion.'",
								"Mailing_City":"'.$Billcity.'",
								"Mailing_Country":"'.$Billcountry_id.'",
								"Mailing_State":"'.$Billregion.'",
								"Mailing_Street":"'.$BillStreet.'",
								"Mailing_Zip":"'.$Billpostcodee.'",
								},';
                $cust_body2.=rtrim($cust_body, ',');
				$cust_body2.=']
					}';
					echo "CUSTOMER DATA";
		print_r($cust_body2);
					
					$CustUrl="https://www.zohoapis.com/crm/v2/Contacts";
        		$ch = curl_init();
                curl_setopt($ch, CURLOPT_URL,$CustUrl);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
                curl_setopt($ch, CURLOPT_TIMEOUT,30);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);    
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS,$cust_body2);
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST,"POST");
                curl_setopt($ch,CURLOPT_HTTPHEADER, array(
                "Authorization: ".$tokenzoho));
                $result = curl_exec($ch);
        		  echo "<pre>";
        		$CreateResponse=(json_decode($result,true));
        		print_r($CreateResponse);
        	if(isset($CreateResponse['data'][0]['code']) && $CreateResponse['data'][0]['code'] == 'SUCCESS'){
        		$contactID = $CreateResponse['data'][0]['details']['id'];
        	}
					
		}
		/////////////////////
		//GET ORDER DETAILS CRM
			echo "requestSOUrl==>>".$requestSOUrl="https://www.zohoapis.com/crm/v2/Sales_Orders/search?criteria=((Magento_Order_No:equals:{$initial_order_id}))";
				
				$curl = curl_init();

				  curl_setopt_array($curl, array(
				  CURLOPT_URL => $requestSOUrl,
				  CURLOPT_RETURNTRANSFER => true,
				  CURLOPT_ENCODING => "",
				  CURLOPT_MAXREDIRS => 10,
				  CURLOPT_TIMEOUT => 0,
				  CURLOPT_SSL_VERIFYPEER => FALSE,
				  CURLOPT_SSL_VERIFYHOST => FALSE,
				  CURLOPT_FOLLOWLOCATION => true,
				  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				  CURLOPT_CUSTOMREQUEST => "GET",
				  CURLOPT_HTTPHEADER => array(
                    "Authorization: ".$tokenzoho,
                    'Content-Type: application/x-www-form-urlencoded',
                ),
				));
				$response_SO = curl_exec($curl);
                curl_close($curl);
                $responseSOdata = json_decode($response_SO,true);
		//echo "<pre>";
		/*echo "SO==>>>"; echo "</br>";
		print_r($responseSOdata);
		die;*/
		
		if($responseSOdata['data'][0]){
		    $SOID = $responseSOdata['data'][0]['id'];
		    $Subject =$responseSOdata['data'][0]['Subject'];
		}
		//////////////////////////
		
		$product_id=search_zoho_product_id($tokenzoho,urlencode($product_name));
		//print_r($product_id);
		//die;
		//Sales_Orders body for zoho request 
			    $so_body2='';
			     $so_body='';
			     if($cc_exp_month == ''){
			         $cc_exp_month=0;
			     }
			     $so_body.='{
					"data": [{
					"Name": "'.$subscriber_name.'",
						"Billing_Period":"'.$billing_period.'",
						"Billing_Period_Label": "'.$billing_period_label.'",
						"Billing_Frequency": "'.$billing_frequency.'",
						"Period_Max_Cycles": "'.$period_max_cycles.'",
						"Payment_Title": "'.$payment_title.'",
						"Billing_Amount": "'.$billing_amount.'",
						"Product": "'.$product_id.'",
						"Sales_Order": "'.$SOID.'",
						"Magento_Subscription_Id":"'.$subscription_id.'",
						"Contact":"'.$contactID.'",
						"Magento_Product_Id": "'.$magento_product_id.'",
						"Subscription_Start_Date": "'.$subscription_start_date.'",
						"Next_Occurrence_Date": "'.$next_occurrence_date.'",
						"Payment_Method_Code": "'.$payment_method_code.'",
						"Payment_Title": "'.$payment_title.'",
						"Reminder_Frequency": "'.rtrim(ltrim($ReminderAfter,' '),' ').'",
						"Reminder_Method": "'.rtrim($ReminderTypeAfter,' ').'",
						"Change_Filter_Reminder_Date": "'.$ChangeFilterReminderDate.'",';
						
				$so_body2.=rtrim($so_body, ',');
				$so_body2.='}]
					}';
print_r($so_body2);

			//call to salesorderUrl api.
				$salesorderUrl = "https://www.zohoapis.com/crm/v2/Subscriptions/".$subscription_ZcrmID;
				$createOrderRes=postRequest($tokenzoho,$salesorderUrl,$so_body2);
				echo "<pre>";
				
				$createOrderResData = json_decode($createOrderRes,true);
				print_r($createOrderResData);
				if($createOrderResData['data'][0]['code'] == 'SUCCESS'){
				    $ZcrmID = $createOrderResData['data'][0]['details']['id'];
				    
				    
				    
				    $sql = "UPDATE fr_magento_subscriptions SET ZcrmID='".$ZcrmID."', status=1 WHERE subscription_id='".$subscription_id."'";

                    if (mysqli_query($conn, $sql)) {
                      echo "Record updated successfully";
                    } else {
                      echo "Error updating record: " . mysqli_error($conn);
                    }
				    
				    
				}else{
				    
				}
} else {
  
  

}
}
}

//END GET SUBSCRIPTION DATA


}
}
	  //die;
			//Function to post zoho sales order with all data 
			function postRequest($tokenzoho,$url,$body){

                $curl = curl_init();
                curl_setopt_array($curl, array(
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_SSL_VERIFYPEER =>false,
                CURLOPT_SSL_VERIFYHOST=>false,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "PUT",
                CURLOPT_POSTFIELDS =>$body,
                CURLOPT_HTTPHEADER => array(
                    "Authorization: ".$tokenzoho,
                    "Content-Type: application/json",
                ),
                ));
                
                $response = curl_exec($curl);
                curl_close($curl);
                return $response;
               
            }
			
			//search zoho product internal id by its sku
			function search_zoho_product_id($tokenzoho,$SKU){
				$requestUrl="https://www.zohoapis.com/crm/v2/Products/search?criteria=((Product_Code:equals:{$SKU}))";
				//$requestUrl="https://www.zohoapis.com/crm/v2/Products/search?criteria=((Product_Code:equals:240))";
				//echo $requestUrl;
				$curl = curl_init();

				  curl_setopt_array($curl, array(
				  CURLOPT_URL => $requestUrl,
				  CURLOPT_RETURNTRANSFER => true,
				  CURLOPT_ENCODING => "",
				  CURLOPT_MAXREDIRS => 10,
				  CURLOPT_TIMEOUT => 0,
				  CURLOPT_SSL_VERIFYPEER => FALSE,
				  CURLOPT_SSL_VERIFYHOST => FALSE,
				  CURLOPT_FOLLOWLOCATION => true,
				  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				  CURLOPT_CUSTOMREQUEST => "GET",
				  CURLOPT_HTTPHEADER => array(
                    "Authorization: ".$tokenzoho,
                    'Content-Type: application/x-www-form-urlencoded',
                ),
				));
				$response_prodcut = curl_exec($curl);
                curl_close($curl);
                $responsedata = json_decode($response_prodcut,true);
				
				//return $responsedata; 
			
					if(isset($responsedata['data'][0])){
						$productdata=$responsedata['data'][0];
						$productid=$productdata['id'];
						return $productid;
					}			
			}
			
		//search taxes in zoho using names and send internal id in return
		function search_zoho_tax($statename){
				if($statename=="Ontario"){
					$taxdetail='[{
						"percentage": 13,
						"name": "Ontario",
						"id": "4608276000001610035"
					}]';
				}
				if($statename=="Alberta"){
					$taxdetail='[{
						"percentage": 5,
						"name": "Ontario",
						"id": "4608276000001610017"
					}]';
				}
				if($statename=="British Columbia"){
					$taxdetail='[{
						"percentage": 12,
						"name": "BC",
						"id": "4608276000001610021"
					}]';
				}
				if($statename=="Manitoba"){
					$taxdetail='[{
						"percentage": 12,
						"name": "Manitoba",
						"id": "4608276000001610023"
					}]';
				}
				if($statename=="New Brunswick"){
					$taxdetail='[{
					"percentage": 15,
					"name": "NB",
					"id": "4608276000001610025"
					}]';
				}
				if($statename=="Newfoundland and Labrador"){
					$taxdetail='[{
						"percentage": 13,
						"name": "NL",
						"id": "4608276000001610027"
					}]';
				}
				if($statename=="Northwest Territories"){
					$taxdetail='[{
						"percentage": 5,
						"name": "NT",
						"id": "4608276000001610029"
					}]';
				}
				if($statename=="Nova Scotia"){
					$taxdetail='[{
						"percentage": 15,
						"name": "NS",
						"id": "4608276000001610031"
					}]';
				}
				if($statename=="Nunavut"){
					$taxdetail='[{
						"percentage": 5,
						"name": "Nunavut",
						"id": "4608276000001610033"
					}]';
				}
				if($statename=="Prince Edward Island"){
					$taxdetail='[{
							"percentage": 15,
							"name": "PE",
							"id": "4608276000001610037"
						}]';
				}
				if($statename=="Quebec"){
					$taxdetail='[{
						"percentage": 14.975,
						"name": "Quebec",
						"id": "4608276000001610039"
					}]';
				}
				if($statename=="Saskatchewan"){
					$taxdetail='[{
						"percentage": 11,
						"name": "Saskatchewan",
						"id": "4608276000001610041"
					}]';
				}
				if($statename=="Yukon"){
					$taxdetail='[{
					"percentage": 5,
					"name": "Yukon",
					"id": "4608276000001610043"
					}]';
				}
				return 	$taxdetail; 
		}
?>