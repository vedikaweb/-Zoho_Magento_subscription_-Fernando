<?php

include("dbConnect.php");
//Get zoho token from db.
$tokenQuery="SELECT * FROM `fr_oauth_token` where token_type='CRM'";
$tokenQueryRes =$conn->query($tokenQuery);
	if ($tokenQueryRes->num_rows>0) {
		$tokenRow = mysqli_fetch_assoc($tokenQueryRes);
		echo $tokenzoho="Zoho-oauthtoken ".$tokenRow['access_token'];
	}
//die;


	/* $sql = 'SELECT * FROM `fr_magento_products` Order By ID asc LIMIT 20';
$result = mysqli_query($conn, $sql); */
$selectQuery = mysqli_query($conn, "SELECT * FROM `fr_magento_products` WHERE `Zcrm_Pid` IS NULL and temp_status IS NULL");
if (mysqli_num_rows($selectQuery) > 0) {
  // output data of each row
  while($row = mysqli_fetch_assoc($selectQuery)) {
    //echo "id: " . $row["id"]. " - Name: " . $row["firstname"]. " " . $row["lastname"]. "<br>";
	
	 $product_id=search_zoho_product_id($tokenzoho,$row["sku"]);

	echo "Product ID==>>".$product_id;
	echo "</br>";
	if($product_id == ''){
	
	////
	$category_ids = $row["category_ids"];
	//if(strpos($category_ids, ',') !== false){
    //echo "Word Found!";
	$category_ids = rtrim($category_ids, ',');
	
	
	$catIDArray = explode(",",$category_ids);
	//print_r($catIDArray);
	
	//FIND CATEGORY
	$CateGoryName=array();
	foreach($catIDArray as $CatID){
		
		echo $sqlCat = "SELECT * FROM fr_product_categories where ProductCatMagentoId='".$CatID."'"; echo "</br>";
		$resultCat = mysqli_query($conn, $sqlCat);

		if (mysqli_num_rows($resultCat) > 0) {
		  // output data of each row
		  while($rowCat = mysqli_fetch_assoc($resultCat)) {
			  //echo "</br>";  $CateGoryName .=$rowCat['name'].','; echo "</br>";
			  array_push($CateGoryName,$rowCat['name']);
		  }
		}
	}
	//$CateGoryName = rtrim($CateGoryName, ',');
	//$CateGoryName = '[{".$CateGoryName.'}]';
	//print_r(json_encode($CateGoryName)); //$CateGoryName;
	
	
	$description = str_replace(array("\r","\n"),"",$row["description"]);
	$description = str_replace('"',"",$row["description"]);
	$description = str_replace("\'","",$description);
	 $description = strip_tags($description);echo "</br>";
	
	
	$short_description = str_replace(array("\r","\n"),"",$row["short_description"]);
	$short_description = str_replace('"',"",$short_description);
	$short_description = str_replace("\'","",$short_description);
	 $short_description = strip_tags($short_description);
	 
	 $price_text = str_replace(array("\r","\n"),"",$row["price_text"]);
	$price_text = str_replace('"',"",$price_text);
	 $price_text = strip_tags($price_text);
	 
	 
	 $manufacturer_info = str_replace(array("\r","\n"),"",$row["manufacturer_info"]);
	$manufacturer_info = str_replace('"',"",$manufacturer_info);
	$manufacturer_info = str_replace("\'","",$manufacturer_info);
	 $manufacturer_info = strip_tags($manufacturer_info);
	 $manufacturer_info = substr($manufacturer_info, 0, 255);
	
	
	$ProductsRecordsBody='{
                          "data": [
                            {
								"Product_Name":"'.$row["name"].'",
								"Unit_Price":"'.$row["price"].'",
								"Category_Ids":'.json_encode($CateGoryName).',
								"Cost":"'.$row["cost"].'",
								"Description":"'.mysqli_real_escape_string($conn,$description).'",
								"Gift_Message_Available":"'.$row["gift_message_available"].'",
								"Has_Options":"'.$row["has_options"].'",
								"Image":"'.$row["image"].'",
								"Manufacturer":"'.$row["manufacturers"].'",
								"Manufacturer_Equipment_Model_Number":"",
								"Meta_Description":"'.mysqli_real_escape_string($conn,$short_description).'",
								"Short_Description":"'.mysqli_real_escape_string($conn,$short_description).'",
								"Meta_Keyword":"'.mysqli_real_escape_string($conn,$row["meta_keyword"]).'",
								"Meta_Title":"'.mysqli_real_escape_string($conn,$row["meta_title"]).'",
								"MSRP_Display_Actual_Price_Type":"'.$row["msrp_display_actual_price_type"].'",
								"Options_Container":"'.$row["options_container"].'",
								"Part_Number":"'.mysqli_real_escape_string($conn,$row["partnumber"]).'",
								"Product_Height":"'.$row["product_height"].'",
								"Product_Code":"'.$row["sku"].'",
								"Product_Length":"'.$row["product_length"].'",
								"Product_Width":"'.$row["product_width"].'",
								"Ready_to_Ship":"'.$row["ready_to_ship"].'",
								"Search_Weight":"'.$row["search_weight"].'",
								"Tax_Class_ID":"'.$row["tax_class_id"].'",
								"Url_Key":"'.$row["url_key"].'",
								
								"Is_Subscription":"'.$row["is_subscription"].'",
								"Subscription_Type":"'.$row["subscription_type"].'",
								"Ship_req_Proof_of_Age":"'.$row["ship_req_proof_of_age"].'",
								"Discount_Amount":"'.$row["discount_amount"].'",
								"Discount_Type":"'.$row["discount_type"].'",
								"Allow_Trial":"'.$row["allow_trial"].'",
								"Required_Options":"'.$row["required_options"].'",
								"Allow_Update_Date":"'.$row["allow_update_date"].'",
								"Billing_Period":"'.$row["billing_period"].'",
								"Billing_Period_Type":"'.$row["billing_period_type"].'",
								"Manufacturer_Info":"'.mysqli_real_escape_string($conn,$manufacturer_info).'",
								"Item_Type":"'.$row["item_type"].'",
								"Price_Text":"'.$price_text.'",
								"ARP_Override":"'.$row["arp_override"].'",								
								"Product_Supplier":"'.$row["product_supplier"].'",
								"Define_Start_From":"'.$row["define_start_from"].'",								
								"Small_Image":"'.$row["small_image"].'",								
								"Unit_Cost_Year_Updated":"'.$row["unit_cost_year_updated"].'",
								"Tier_Price_Config_For_Store":"'.$row["tier_price_config_for_store"].'",
								"Attribute_Set_Id":"'.$row["attribute_set_id"].'",
								"Tier_Prices":"'.$row["TotalTierPrice"].'",
                            }
                          ]}';
	
	////
	echo "<pre>";
	print_r($ProductsRecordsBody);
	echo "</br>";
		$jobUpdateUrl="https://www.zohoapis.com/crm/v2/Products";
		$ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,$jobUpdateUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
        curl_setopt($ch, CURLOPT_TIMEOUT,30);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);    
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS,$ProductsRecordsBody);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST,"POST");
        curl_setopt($ch,CURLOPT_HTTPHEADER, array(
        "Authorization: ".$tokenzoho));
        $result = curl_exec($ch);
		  echo "<pre>";
		$updateResponse=(json_decode($result,true));
		print_r($updateResponse);
	if(isset($updateResponse['data'][0]['code']) && $updateResponse['data'][0]['code'] == 'SUCCESS'){
		$zCrmPID = $updateResponse['data'][0]['details']['id'];
		$sql = "UPDATE fr_magento_products SET Zcrm_Pid='".$zCrmPID."',temp_status='1' WHERE ID='".$row["ID"]."'";

		if (mysqli_query($conn, $sql)) {
		  echo "Record updated successfully";
		} else {
		  echo "Error updating record: " . mysqli_error($conn);
		}
	}
//}	
	
  } else{
      $sql = "UPDATE fr_magento_products SET Zcrm_Pid='".$product_id."',temp_status='1' WHERE ID='".$row["ID"]."'";

		if (mysqli_query($conn, $sql)) {
		  echo "Record updated successfully";
		} else {
		  echo "Error updating record: " . mysqli_error($conn);
		}
  }
  }
} else {
  echo "0 results";
}

//die;

//function to call get api call from Mangento
function curl_call($token,$requestUrl){
       
	$curl = curl_init();

  curl_setopt_array($curl, array(
  CURLOPT_URL => $requestUrl,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_SSL_VERIFYPEER => FALSE,
  CURLOPT_SSL_VERIFYHOST => FALSE,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_HTTPHEADER => array(
    "Content-Type: application/json",
    "Authorization: Bearer tjfij5xewlkj2qk03ujbio8k9b0mf2bb",
    "Cookie: PHPSESSID=rs86nf23vp7v0g5ufa5khljsh6"
  ),
));
	$response = curl_exec($curl);
	curl_close($curl);
    $responsedata = json_decode($response,true);
    return $responsedata; 
		          
} //function curl_call end
      
	  
	  
//search zoho product internal id by its sku
			function search_zoho_product_id($tokenzoho,$SKU){
				$requestUrl="https://www.zohoapis.com/crm/v2/Products/search?criteria=((Product_Code:equals:{$SKU}))";
				//$requestUrl="https://www.zohoapis.com/crm/v2/Products/search?criteria=((Product_Code:equals:240))";
				//echo $requestUrl;
				$curl = curl_init();

				  curl_setopt_array($curl, array(
				  CURLOPT_URL => $requestUrl,
				  CURLOPT_RETURNTRANSFER => true,
				  CURLOPT_ENCODING => "",
				  CURLOPT_MAXREDIRS => 10,
				  CURLOPT_TIMEOUT => 0,
				  CURLOPT_SSL_VERIFYPEER => FALSE,
				  CURLOPT_SSL_VERIFYHOST => FALSE,
				  CURLOPT_FOLLOWLOCATION => true,
				  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				  CURLOPT_CUSTOMREQUEST => "GET",
				  CURLOPT_HTTPHEADER => array(
                    "Authorization: ".$tokenzoho,
                    'Content-Type: application/x-www-form-urlencoded',
                ),
				));
				$response_prodcut = curl_exec($curl);
                curl_close($curl);
                $responsedata = json_decode($response_prodcut,true);
				
				//return $responsedata; 
			
					if(isset($responsedata['data'][0])){
						$productdata=$responsedata['data'][0];
						$productid=$productdata['id'];
						return $productid;
					}			
			}
?>			
  