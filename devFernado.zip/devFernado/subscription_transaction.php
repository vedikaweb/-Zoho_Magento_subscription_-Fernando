<?php 
	require("dbConnect.php");
	require('oauth_token_zoho.php');
	//Get zoho token from db.
	$token="";
	$tokenQuery="SELECT * FROM `fr_oauth_token` where token_type='CRM'";
	$tokenQueryRes =$conn->query($tokenQuery);
	if ($tokenQueryRes->num_rows>0) {
		$tokenRow = mysqli_fetch_assoc($tokenQueryRes);
		$token="Zoho-oauthtoken ".$tokenRow['access_token'];
	}

	$subscription_id="";
	if(isset($_POST['subscription_id'])){
		$subscription_id=$_POST['subscription_id'];
		//$subscription_id="4608276000002126001";
		$url="https://www.zohoapis.com/crm/v2/Subscription_Transactions/".$subscription_id;
		$transactionRes=GetTransactionInfo($url,$token);
		/*echo "<pre>";
		print_r($transactionRes);*/
		$subData=$transactionRes['data'][0];
		$subTransactionArr=Array(
            'Email'=> $subData['Email'],
            'Customer_Response_Message'=> $subData['Customer_Response_Message'],
            'Subscription_Start_Date'=> $subData['Subscription_Start_Date'],
            'Customer_Response'=> $subData['Customer_Response'],
            'Next_Occurance_Date'=> $subData['Next_Occurance_Date'],
            'Name'=> $subData['Name'],
            'Unsubscribed_Mode'=> $subData['Unsubscribed_Mode'],
            'trans_Id'=> $subData['id'],
            'Customer_Response_Date_Time'=> $subData['Customer_Response_Date_Time'],
            'Modified_Time'=> $subData['Modified_Time'],
            'Created_Time'=> $subData['Created_Time'],
            'Unsubscribed_Time'=> $subData['Unsubscribed_Time'],
            'Subscription_Name'=> $subData['Subscription_Name']['name'],
            'Subscription_Id'=> $subData['Subscription_Name']['id'],
        );
                   
		// check dealInfo details is present in database or not if present then update otherwise insert
		$checkdeal="select `trans_Id` from `fr_magento_sub_transaction` where `trans_Id`='".$subTransactionArr['trans_Id']."'";
		$checkdealRes=$conn->query($checkdeal);
		if($checkdealRes->num_rows>0) {              
		$i = 0;
		$arr2 = array();
		  foreach ($subTransactionArr as $key => $value) {
		    $arr2[$i] = $key."='".mysqli_real_escape_string($conn,$value)."'";
		    $i++;
		    $subTransactionArr[$key] = mysqli_real_escape_string($conn,$value);
		  }
		  $update_colum=implode(",",$arr2);                 
		  $updateTrancSql="UPDATE `fr_magento_sub_transaction` SET ".$update_colum." where `trans_Id`='".$subTransactionArr['trans_Id']."'";
		  $updateTrancRes = $conn->query($updateTrancSql);
		}else{                    
		  $insertTranSql ="INSERT INTO fr_magento_sub_transaction (".implode(",",array_keys($subTransactionArr)).") VALUES ('" . implode("','",array_values($subTransactionArr))."')";     
		  $insertTranRes = $conn->query($insertTranSql);
		}

		//here we will get subscription details from table subscription
		if(isset($subData['Subscription_Name']['id'])){

			//here we will get Invoice details
			$subscriptionSql="SELECT subscription_id FROM `fr_magento_subscriptions` where ZcrmID='".$subData['Subscription_Name']['id']."'";
			$subscriptionRes =$conn->query($subscriptionSql);
			if ($subscriptionRes->num_rows>0) {

			    $subRow = mysqli_fetch_assoc($subscriptionRes);

			    // here we will upate records in magento
				$subUpdateBoy='{
								  "subscriptionId":"'.$subRow['subscription_id'].'",
								}';
				//echo "<pre>";
				//print_r($subUpdateBoy);
				$type="";
				if($subTransactionArr['Customer_Response']=='Hold'){
					$type="pause";
				}
				if($subTransactionArr['Customer_Response']=='Accepted'){
					$type="resume";
				}
				if($subTransactionArr['Customer_Response']=='Declined'){
					$type="cancel";
				}
				
				$updateUrl="http://52.25.19.29/ca/rest/all/V1/subscription".$type;
				if($type!=''){
						$subRes=updateSubscription($subUpdateBoy,$updateUrl);
						echo $type."--------------------<pre>";
						print_r($subRes);
				}
				
				//V1/subscription/pause
				//V1/subscription/resume
				//V1/subscription/cancel
			}
		}
		
	}

	function GetTransactionInfo($url,$token){
			$curl = curl_init();
			curl_setopt_array($curl, array(
			CURLOPT_URL => $url,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 0,
			CURLOPT_SSL_VERIFYPEER => FALSE,
			CURLOPT_SSL_VERIFYHOST => FALSE,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => "GET",
			CURLOPT_HTTPHEADER => array(
			"Authorization: ".$token,
			'Content-Type: application/x-www-form-urlencoded',
			),
			));
			$res_transaction = curl_exec($curl);
			curl_close($curl);
			return json_decode($res_transaction,true);
	}

	function updateSubscription($body,$requestUrl){
       
			$curl = curl_init();
			curl_setopt_array($curl, array(
			CURLOPT_URL => $requestUrl,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 0,
			CURLOPT_SSL_VERIFYPEER => FALSE,
			CURLOPT_SSL_VERIFYHOST => FALSE,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => "PUT",
			CURLOPT_POSTFIELDS =>$body,
			CURLOPT_HTTPHEADER => array(
				"Content-Type: application/json",
				"Authorization: Bearer tjfij5xewlkj2qk03ujbio8k9b0mf2bb",
				"Cookie: PHPSESSID=rs86nf23vp7v0g5ufa5khljsh6"
			),
			));
			$response = curl_exec($curl);
			curl_close($curl);
			return json_decode($response,true);
	}
?>
                