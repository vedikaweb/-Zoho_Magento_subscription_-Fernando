<?php

  require("dbConnect.php");
  getZohoAccessToken($conn);
  //getXeroAccessToken($conn);

  function getZohoAccessToken($conn){

      echo $current_time = date("Y-m-d H:i:s");
      $getTokenSql="SELECT access_token,expiry_time FROM `fr_oauth_token` where token_type='CRM'";
      $getTokenSqlRes=$conn->query($getTokenSql);
      if($getTokenSqlRes->num_rows>0) {

            $getTokenSqlResData=mysqli_fetch_assoc($getTokenSqlRes);

            if(strtotime($current_time) < strtotime($getTokenSqlResData['expiry_time'])){
                //return $token = "Zoho-oauthtoken".' '.$getTokenSqlResData['access_token']; 
            }else{
                 ZohoAccessToken($conn);
            }
      }
  }

  function getXeroAccessToken($conn){
		
		XeroAccessToken($conn);
      /* $current_time = date("Y-m-d H:i:s");
      $getTokenSql="SELECT access_token,expiry_time FROM `fr_oauth_token` where token_type='XERO'";
      $getTokenSqlRes=$conn->query($getTokenSql);
      if($getTokenSqlRes->num_rows>0) {

            $getTokenSqlResData=mysqli_fetch_assoc($getTokenSqlRes);

            if(strtotime($current_time) < strtotime($getTokenSqlResData['expiry_time'])){
                //return $token = "Bearer".' '.$getTokenSqlResData['access_token']; 
            }else{
               XeroAccessToken($conn);
            }
      } */
  }

	// this funtion will genrate new acces token and store into database
	function ZohoAccessToken($conn){

        $current_time = date("Y-m-d H:i:s");
        $getTokenSql="SELECT * FROM `fr_oauth_token` where token_type='CRM'";
        $getTokenSqlRes=$conn->query($getTokenSql);
        if($getTokenSqlRes->num_rows>0) {
            $getTokenData=mysqli_fetch_assoc($getTokenSqlRes);
            
            $url="https://accounts.zoho.com/oauth/v2/token?refresh_token=".$getTokenData['refresh_token']."&grant_type=refresh_token&client_id=".$getTokenData['client_id']."&client_secret=".$getTokenData['client_secret']."&redirect_uri=".$getTokenData['redirect_uri']."&scope=zohoCRM.modules.ALL";
      
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL,$url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
            curl_setopt($ch, CURLOPT_TIMEOUT,30);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE); 
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            $curlCallResponse = curl_exec($ch);
            $oauth2RefreshTokenResponse = json_decode($curlCallResponse,true);
            
            if(isset($oauth2RefreshTokenResponse['access_token'])){
               $updateAccessToken="UPDATE `fr_oauth_token` SET `access_token`='".$oauth2RefreshTokenResponse['access_token']."',`created_time`='".$current_time."',`expiry_time`='".date("Y-m-d H:i:s",strtotime('+1 hour',strtotime($current_time)))."' WHERE token_type='CRM'";
               $updateAccessTokenRes=$conn->query($updateAccessToken);   
            }
            //return "Zoho-oauthtoken".' '.$oauth2RefreshTokenResponse['access_token'];
        }
    }


    function XeroAccessToken($conn){

      $current_time = date("Y-m-d H:i:s");
      $getAccessCredential="SELECT * FROM `fr_oauth_token` where token_type='XERO'";
      $getAccessCredentialRes=$conn->query($getAccessCredential);
       if ($getAccessCredentialRes->num_rows > 0) {
            $accessData = mysqli_fetch_assoc($getAccessCredentialRes);

            $curl = curl_init();
            curl_setopt_array($curl, array(
              CURLOPT_URL => "https://identity.xero.com/connect/token",
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 0,
              CURLOPT_FOLLOWLOCATION => true,
              CURLOPT_SSL_VERIFYHOST =>false,
              CURLOPT_SSL_VERIFYPEER=>false,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "POST",
              CURLOPT_POSTFIELDS => "grant_type=refresh_token&refresh_token=".$accessData['refresh_token'],
              CURLOPT_HTTPHEADER => array(
                "authorization: Basic ".base64_encode($accessData['client_id'].":".$accessData['client_secret']),
                "Content-Type: application/x-www-form-urlencoded"
              ),
            ));

              $response = curl_exec($curl);
              $xeroDataRes=json_decode($response,true);
              //create array to store org information
              $xeroCredentialInfo=Array(
                    'access_token' => isset($xeroDataRes['access_token']) ? $xeroDataRes['access_token'] : '',                                   
                    'refresh_token' => isset($xeroDataRes['refresh_token']) ? $xeroDataRes['refresh_token'] : '', 
                    'created_time' => date("Y-m-d H:i:s"),
                    'expiry_time' => date("Y-m-d H:i:s",strtotime('+1 hour',strtotime($current_time))),
                    'token_type'=> 'XERO', 
                );

              if(isset($xeroDataRes['access_token'])){
                  $i = 0;
                  $arr2 = array();
                  foreach ($xeroCredentialInfo as $key => $value) {
                    $arr2[$i] = $key."='".mysqli_real_escape_string($conn,$value)."'";
                    $i++;
                    $xeroCredentialInfo[$key] = mysqli_real_escape_string($conn,$value);
                  }
                  $update_colum=implode(",",$arr2);
                  $updateUserSql="UPDATE `fr_oauth_token` SET ".$update_colum." where `token_type`='XERO'";
                  $updateUserSqlRes = $conn->query($updateUserSql);
              }
            curl_close($curl);

            //return "Bearer".' '.$xeroCredentialInfo['access_token'];
        }
    }
?>