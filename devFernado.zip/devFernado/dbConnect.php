<?php
/*
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fernando_db";*/

 $servername = "localhost";
	 $username = "sf_netSuite";
	 $password = "sf_netSuite";
	 $dbname = "cameron_sf_netSuite";


global $conn;
global $connection_string;
$connection_string="mysqli://".$username.":@".$servername."/".$dbname;
// Create connection
$conn = new mysqli($servername,$username,$password,$dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} else {
  //echo "Connection Succesful";
}
?>